# opa-secrets
Credit to [congon4tor](https://github.com/congon4tor/opa_secrets) for original source code
